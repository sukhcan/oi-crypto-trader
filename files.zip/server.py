"""
OI Dashboard Server
====================
Ek lightweight HTTP server jo oi_signal.json ko browser mein serve karta hai.
Dashboard is server se real-time data leta hai.

Run: python server.py
"""

import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

SIGNAL_FILE = Path(__file__).parent / "signals" / "oi_signal.json"
PORT        = 8765


class Handler(BaseHTTPRequestHandler):

    def do_GET(self):
        # CORS headers — browser ko allow karta hai
        if self.path == "/signal":
            self._serve_signal()
        elif self.path == "/" or self.path == "/dashboard":
            self._serve_dashboard()
        else:
            self.send_response(404)
            self.end_headers()

    def _serve_signal(self):
        try:
            data = SIGNAL_FILE.read_text(encoding="utf-8")
            json.loads(data)   # validate
            self.send_response(200)
            self.send_header("Content-Type",  "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(data.encode())
        except FileNotFoundError:
            self._json_error(503, "Signal file not found — Python main.py chal raha hai?")
        except Exception as e:
            self._json_error(500, str(e))

    def _serve_dashboard(self):
        dash = Path(__file__).parent / "dashboard.html"
        try:
            html = dash.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(html)
        except FileNotFoundError:
            self._json_error(404, "dashboard.html not found")

    def _json_error(self, code, msg):
        body = json.dumps({"error": msg}).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # Sirf errors print karo, har request nahi
        if args and str(args[1]) not in ("200", "304"):
            print(f"[server] {fmt % args}")


def main():
    print("=" * 50)
    print("  OI Dashboard Server")
    print("=" * 50)
    print(f"  Signal file : {SIGNAL_FILE}")
    print(f"  Dashboard   : http://localhost:{PORT}/dashboard")
    print(f"  Signal API  : http://localhost:{PORT}/signal")
    print("  Ctrl+C se band karo")
    print("=" * 50)

    if not SIGNAL_FILE.exists():
        print(f"\n  WARNING: {SIGNAL_FILE} abhi nahi mila.")
        print("  Pehle main.py chalao — phir yeh server.")

    server = HTTPServer(("localhost", PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[server] Band ho gaya.")


if __name__ == "__main__":
    main()
